http://web1.foxhollow.ca/cpm/RETRO-VT220-Font/RETRO-VT220-Font.zip

For that RETRO look:

copy Glass_TTY_VT220.ttf into c:\windows\fonts

start your favorite terminal emulator,
examples: secureCRT, putty, terra term

Make sure you change the default font to the new Glass font.

Go into terminal screen color settings:
  set the font color: red=0, blue=0, green=175
  
  set the bold color: red=0, blue=0, green=225
  
  set the background: red=0, blue=0, green=6 
  (if you like more green as the background, increase this number) 


Some small adjustments of the 'green' will vary the brightness

Enjoy!
